
#include <iostream>
using namespace std;

int main()
{
    int temperature;

    cout << "Enter temperature: ";
    cin >> temperature;

    if (temperature > 30)
    {
        cout << "Result: Hot";
    }
    else
    {
        cout << "Result: Cold";
    }

    return 0;
}

